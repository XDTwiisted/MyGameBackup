using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using System;
using Button = UnityEngine.UI.Button;
using Image = UnityEngine.UI.Image;

public class GearUpWeaponSelector : MonoBehaviour
{
    [Header("UI References")]
    public Button weaponSlotButton;
    public GameObject itemSelectionPanel;
    public TextMeshProUGUI selectionTitle;
    public Transform itemScrollViewContent;
    public GameObject weaponSlotPrefab;
    public Transform weaponSlotIconTarget;

    private void Start()
    {
        weaponSlotButton.onClick.AddListener(OpenWeaponSelection);
        if (itemSelectionPanel != null)
            itemSelectionPanel.SetActive(false);
    }

    void OpenWeaponSelection()
    {
        Debug.Log("Opening weapon selection...");

        if (itemSelectionPanel != null)
            itemSelectionPanel.SetActive(true);

        if (selectionTitle != null)
            selectionTitle.text = "Select a Weapon";

        foreach (Transform child in itemScrollViewContent)
        {
            Destroy(child.gameObject);
        }

        List<InventoryEntry> inventory = InventoryManager.Instance.inventory;

        foreach (InventoryEntry entry in inventory)
        {
            if (entry.itemData.category == "Weapon" && entry.quantity > 0)
            {
                Debug.Log("Showing weapon in selector: " + entry.itemData.itemName);

                GameObject slotGO = Instantiate(weaponSlotPrefab, itemScrollViewContent);
                slotGO.name = "WeaponSlot_" + entry.itemData.itemName;

                RectTransform rt = slotGO.GetComponent<RectTransform>();
                if (rt != null)
                {
                    rt.sizeDelta = new Vector2(900f, 100f);
                    rt.localScale = Vector3.one;
                    rt.anchoredPosition3D = Vector3.zero;

                    Debug.Log("Created slot RectTransform - Anchors: " + rt.anchorMin + " to " + rt.anchorMax + ", sizeDelta: " + rt.sizeDelta + ", scale: " + rt.localScale + ", pos: " + rt.localPosition);
                }

                Transform itemInfo = slotGO.transform.Find("ItemInfo");
                if (itemInfo != null)
                {
                    Transform iconTransform = itemInfo.Find("Icon");
                    if (iconTransform != null)
                    {
                        Image iconImage = iconTransform.GetComponent<Image>();
                        if (iconImage != null)
                        {
                            iconImage.sprite = entry.itemData.icon;
                            Debug.Log("Assigned icon: " + entry.itemData.icon.name);
                        }
                        else
                        {
                            Debug.LogWarning("Icon Image component missing on 'Icon' GameObject.");
                        }
                    }
                    else
                    {
                        Debug.LogWarning("'Icon' GameObject not found inside ItemInfo.");
                    }
                }
                else
                {
                    Debug.LogWarning("ItemInfo transform not found inside slot prefab.");
                }

                Button button = slotGO.GetComponent<Button>();
                if (button != null)
                {
                    InventoryItemData capturedItem = entry.itemData;
                    button.onClick.AddListener(() => AssignWeapon(capturedItem));
                }
                else
                {
                    Debug.LogWarning("Button component not found on weapon slot prefab.");
                }
            }
        }

        LayoutRebuilder.ForceRebuildLayoutImmediate(itemScrollViewContent.GetComponent<RectTransform>());
    }

    void AssignWeapon(InventoryItemData selectedItem)
    {
        Debug.Log("Selected weapon: " + selectedItem.itemName);

        if (weaponSlotIconTarget != null)
        {
            Transform iconTransform = weaponSlotIconTarget.Find("Icon");
            if (iconTransform != null)
            {
                Image iconImage = iconTransform.GetComponent<Image>();
                if (iconImage != null)
                {
                    iconImage.sprite = selectedItem.icon;
                }
            }
        }

        if (itemSelectionPanel != null)
            itemSelectionPanel.SetActive(false);
    }
}
